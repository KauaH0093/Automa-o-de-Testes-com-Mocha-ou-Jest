const assert = require('assert');  

describe('Array', function() {  
    describe('#indexOf()', function() {  
        it('deve retornar -1 quando o valor não é encontrado', function() {  
            assert.strictEqual([1, 2, 3].indexOf(4), -1);  
        });  
        it('deve retornar o índice correto quando o valor é encontrado', function() {  
            assert.strictEqual([1, 2, 3].indexOf(2), 1);  
        });  
    });  
});